var mongoose = require("mongoose");
var express = require('express');
var bodyParser = require("body-parser");

var app = express();
var cors = require('cors');
app.use(cors());
app.use(bodyParser.json());
mongoose.connect("mongodb://localhost/jetbrains");

var Product = mongoose.model("Product", {SalesTransaction: String, storeId:String});
var BackupProduct = mongoose.model("BackupProduct", {SalesTransaction:String, storeId:String});

app.get('/', function (req, res) {
    Product.find(function (err, products) {
        res.send(products);
    })
});
app.post('/add', function (req, res) {
    var newProd = req.body.name;
    var storeId = req.body.storeId;
    var product = new Product({SalesTransaction: newProd,storeId:storeId});
    product.save(function (err) {
        res.send();
        if (err) {
            console.log('failed');
        } else {
            console.log("saved")
        }
    });
});

app.get('/copy', function(req, res){
    Product.find(function (err, products) {
        console.log(products);
        for(var i =0; i<products.length;i++){
            var backupProduct = new BackupProduct({SalesTransaction:products[i].SalesTransaction, storeId:products[i].storeId});
            setTimeout(save, 5000,backupProduct);
        }

        function save (backupProduct){
            backupProduct.save(function(err){
                res.send();
                if (err){
                    console.log("failed to copy")
                }else {
                    console.log('Copied')
                }
            });
        }
    });
});

app.get('/getBackupData', function (req, res) {
    BackupProduct.find(function (err, products) {
        res.send(products);
    })
});
app.listen(3000);


